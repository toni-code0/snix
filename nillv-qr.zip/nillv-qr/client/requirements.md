## Packages
qrcode.react | Rendering QR codes on the client side
framer-motion | Smooth page transitions and ad simulations
recharts | Visualizing scan statistics
date-fns | Formatting dates for the dashboard and analytics
html-to-image | Downloading QR codes as images

## Notes
Unity Ads are not supported on web. Visual placeholders are implemented to simulate the ad experience for development/testing purposes.
Authentication uses Replit Auth.
